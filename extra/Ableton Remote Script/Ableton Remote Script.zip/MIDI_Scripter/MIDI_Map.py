# Avoid using tabs for indentation, use spaces.
# Don't use floats, they might break things.


# Combination Mode offsets
# ------------------------

# offset from the left of linked session origin; set to -1 for auto-joining of multiple instances
TRACK_OFFSET = -1
# offset from the top of linked session origin (no auto-join)
SCENE_OFFSET = 0

# Buttons / Pads
# -------------
# Valid Note/CC assignments are 0 to 127, or -1 for NONE
# Duplicate assignments are permitted

BUTTONCHANNEL = 14  # Channel assignment for all mapped buttons/pads; valid range is 0 to 15
BUTTONMESSAGETYPE = 0  # Message type for buttons/pads; set to 0 for MIDI Notes, 1 for CCs.
# When using CCs for buttons/pads, set BUTTONCHANNEL and SLIDERCHANNEL to different values.


# Track selection box (aka that coloured box for scene/track launching)
TSB_X = 8  # Controls the horizontal value for the track selection box. Default value is 8
TSB_Y = 8  # Controls the horizontal value for the track selection box. Default value is 8

# General
PLAY = 1  # Global play
STOP = 2  # Global stop
REC = 3  # Global record
TAPTEMPO = 4  # Tap tempo
NUDGEUP = 5  # Tempo Nudge Up
NUDGEDOWN = 6  # Tempo Nudge Down
UNDO = 7  # Undo
REDO = 8  # Redo
LOOP = 9  # Loop on/off
PUNCHIN = 10  # Punch in
PUNCHOUT = 11  # Punch out
OVERDUB = 12  # Overdub on/off
METRONOME = 13  # Metronome on/off
RECQUANT = 14  # Record quantization on/off
DETAILVIEW = 15  # Detail view switch
CLIPTRACKVIEW = 16  # Clip/Track view switch

# Device Control
DEVICELOCK = 17  # Device Lock (lock "blue hand"
DEVICEONOFF = 18  # Device on/off
DEVICENAVLEFT = 19  # Device nav left
DEVICENAVRIGHT = 20  # Device nav right
DEVICEBANKNAVLEFT = 21  # Device bank nav left
DEVICEBANKNAVRIGHT = 22  # Device bank nav right
# All 8 banks must be assigned to positive values in order for bank selection to work
DEVICEBANK = (
    23,  # Bank 1
    24,  # Bank 2
    25,  # Bank 3
    26,  # Bank 4
    27,  # Bank 5
    28,  # Bank 6
    29,  # Bank 7
    30,  # Bank 8
)

# Arrangement View Controls
SEEKFWD = 31  # Seek forward
SEEKRWD = 32  # Seek rewind

# Session Navigation (aka "red box")
SESSIONLEFT = 33  # Session left
SESSIONRIGHT = 34  # Session right
SESSIONUP = 35  # Session up
SESSIONDOWN = 36  # Session down
ZOOMUP = 37  # Session Zoom up
ZOOMDOWN = 38  # Session Zoom down
ZOOMLEFT = 39  # Session Zoom left
ZOOMRIGHT = 40  # Session Zoom right

# Track Navigation
TRACKLEFT = 41  # Track left
TRACKRIGHT = 42  # Track right

# Scene Navigation
SCENEUP = 43  # Scene down
SCENEDN = 44  # Scene up

# Scene Launch
SELSCENELAUNCH = 45  # Selected scene launch
SCENELAUNCH = (
    46,  # Scene 1 Launch
    47,  # Scene 2
    48,  # Scene 3
    49,  # Scene 4
    50,  # Scene 5
    51,  # Scene 6
    52,  # Scene 7
    53,  # Scene 8
)

# Clip Launch / Stop
SELCLIPLAUNCH = 53  # Selected clip launch
STOPALLCLIPS = 54  # Stop all clips

# Track Control
MASTERSEL = 55  # Master track select
SELTRACKREC = 56  # Arm Selected Track
SELTRACKSOLO = 57  # Solo Selected Track
SELTRACKMUTE = 58  # Mute Selected Track

TRACKSTOP = (
    59,  # Track 1 Clip Stop
    60,  # Track 2
    61,  # Track 3
    62,  # Track 4
    63,  # Track 5
    64,  # Track 6
    65,  # Track 7
    66,  # Track 8
)

TRACKSEL = (
    67,  # Track 1 Select
    68,  # Track 2
    69,  # Track 3
    70,  # Track 4
    71,  # Track 5
    72,  # Track 6
    73,  # Track 7
    74,  # Track 8
)

TRACKMUTE = (
    75,  # Track 1 On/Off
    76,  # Track 2
    77,  # Track 3
    78,  # Track 4
    79,  # Track 5
    80,  # Track 6
    81,  # Track 7
    82,  # Track 8
)

TRACKSOLO = (
    83,  # Track 1 Solo
    84,  # Track 2
    85,  # Track 3
    86,  # Track 4
    87,  # Track 5
    88,  # Track 6
    89,  # Track 7
    90,  # Track 8
)

TRACKREC = (
    91,  # Track 1 Record
    92,  # Track 2
    93,  # Track 3
    94,  # Track 4
    95,  # Track 5
    96,  # Track 6
    97,  # Track 7
    98,  # Track 8
)


# Pad Translations for Drum Rack
PADCHANNEL = 14  # MIDI channel for Drum Rack notes
# MIDI note numbers for 4 x 4 Drum Rack, mapping will be disabled if any notes are set to -1
DRUM_PADS = (
    1,
    2,
    3,
    4,
    5,
    6,
    7,
    8,
    9,
    10,
    11,
    12,
    13,
    14,
    15,
    16,
)


# Clip launchers
CLIPCHANNEL = 15  # Channel assignment for clip launchers; valid range is 0 to 15 ; 0=1, 1=2 etc.
CLIPMESSAGETYPE = 0  # Message type for clip launchers; set to 0 for MIDI Notes, 1 for CCs.

# 8x8 Matrix note assignments
# Track no.:     1   2   3   4   5   6   7   8
CLIPNOTEMAP = (
    (
        11,
        12,
        13,
        14,
        15,
        16,
        17,
        18,
    ),  # Row 1
    (
        21,
        22,
        23,
        24,
        25,
        26,
        27,
        28,
    ),  # Row 2
    (
        31,
        32,
        33,
        34,
        35,
        36,
        37,
        38,
    ),  # Row 3
    (
        41,
        42,
        43,
        44,
        45,
        46,
        47,
        48,
    ),  # Row 4
    (
        51,
        52,
        53,
        54,
        55,
        56,
        57,
        58,
    ),  # Row 5
    (
        61,
        62,
        63,
        64,
        65,
        66,
        67,
        68,
    ),  # Row 6
    (
        71,
        72,
        73,
        74,
        75,
        76,
        77,
        78,
    ),  # Row 7
    (
        81,
        82,
        83,
        84,
        85,
        86,
        87,
        88,
    ),  # Row 8
)


# Sliders / Knobs
# ---------------
# Valid CC assignments are 0 to 127, or -1 for NONE
# Duplicate assignments will be ignored
SLIDERCHANNEL = 14  # Channel assignment for all mapped CCs; valid range is 0 to 15
SLIDERMESSAGETYPE = 1  # Don't change
TEMPO_TOP = 140.0  # Upper limit of tempo control in BPM (max is 999)
TEMPO_BOTTOM = 40.0  # Lower limit of tempo control in BPM (min is 0)

TEMPOCONTROL = 1  # Tempo control CC assignment
MASTERVOLUME = 2  # Master track volume
CUELEVEL = 3  # Cue level control
CROSSFADER = 4  # Crossfader control

TRACKVOL = (
    5,  # Track 1 Volume
    6,  # Track 2
    7,  # Track 3
    8,  # Track 4
    9,  # Track 5
    10,  # Track 6
    11,  # Track 7
    12,  # Track 8
)

TRACKPAN = (
    13,  # Track 1 Pan
    14,  # Track 2
    15,  # Track 3
    16,  # Track 4
    17,  # Track 5
    18,  # Track 6
    19,  # Track 7
    20,  # Track 8
)

TRACKSENDA = (
    21,  # Track 1 Send A
    22,  # Track 2
    23,  # Track 3
    24,  # Track 4
    25,  # Track 5
    26,  # Track 6
    27,  # Track 7
    28,  # Track 8
)

TRACKSENDB = (
    29,  # Track 1 Send B
    30,  # Track 2
    31,  # Track 3
    32,  # Track 4
    33,  # Track 5
    34,  # Track 6
    35,  # Track 7
    36,  # Track 8
)

TRACKSENDC = (
    37,  # Track 1 Send C
    38,  # Track 2
    39,  # Track 3
    40,  # Track 4
    41,  # Track 5
    42,  # Track 6
    43,  # Track 7
    44,  # Track 8
)

#  All 8 params must be assigned to positive values in order for param control to work
PARAMCONTROL = (
    45,  # Param 1
    46,  # Param 2
    47,  # Param 3
    48,  # Param 4
    49,  # Param 5
    50,  # Param 6
    51,  # Param 7
    52,  # Param 8
)
