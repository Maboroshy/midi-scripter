import Live
from .MidiScripter import MidiScripter


def create_instance(c_instance):
    """Creates and returns the APC20 script"""
    return MidiScripter(c_instance)


# local variables:
# tab-width: 4
